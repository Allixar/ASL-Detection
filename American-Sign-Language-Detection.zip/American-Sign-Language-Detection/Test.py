from vpython import *
import threading
import time
import math
import librosa
import pygame

# --- LOAD BEAT DATA ---
y, sr = librosa.load(r"D:\Savannah Another One\Savannah.wav")
tempo, beat_frames = librosa.beat.beat_track(y=y, sr=sr)
beat_times = librosa.frames_to_time(beat_frames, sr=sr)

# --- MUSIC PLAYBACK THREAD ---
def play_music():
    pygame.mixer.init()
    pygame.mixer.music.load(r"D:\Savannah Another One\Savannah.wav")
    pygame.mixer.music.play()

threading.Thread(target=play_music, daemon=True).start()

# --- VPYTHON SETUP ---
scene = canvas(title='Epic 3D Beat Animation', background=color.black)
text_obj = text(text='Johanna', align='center', height=2, depth=0.5, color=color.orange, emissive=True)

# --- PARAMETERS ---
bounce_height = 1.2
bounce_duration = 0.2
base_scale = vector(1, 1, 1)
glow_colors = [color.orange, color.red, color.white, color.yellow]

# --- ANIMATION LOOP ---
start_time = time.time()
next_beat_index = 0
bounce_active = False
bounce_start_time = 0

while True:
    rate(120)
    current_time = time.time() - start_time

    # Trigger beat actions
    if next_beat_index < len(beat_times) and current_time >= beat_times[next_beat_index]:
        bounce_active = True
        bounce_start_time = current_time
        next_beat_index += 1

        # Random glow color on beat
        text_obj.color = glow_colors[next_beat_index % len(glow_colors)]

    # Bounce effect
    if bounce_active:
        elapsed = current_time - bounce_start_time
        if elapsed < bounce_duration:
            y_offset = bounce_height * math.sin((elapsed / bounce_duration) * math.pi)
            scale_factor = 1 + 0.3 * math.sin((elapsed / bounce_duration) * math.pi)
            text_obj.size = base_scale * scale_factor
        else:
            y_offset = 0
            text_obj.size = base_scale
            bounce_active = False
    else:
        y_offset = 0

    # Apply position and rotation
    text_obj.rotate(angle=0.03, axis=vector(0, 1, 0))
    text_obj.pos.y = y_offset
